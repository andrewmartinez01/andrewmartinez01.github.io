import numpy as np
import matplotlib.pyplot as plt
import os.path

def Stats(directory = os.path.dirname(os.path.abspath(__file__))):
    filename = os.path.join(directory, 'TerroristActs.csv')
    datafile = open(filename,'r')
    data = datafile.readlines()
    Foreign = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    Domestic=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    IllImmPop=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    for line in data[1:]: # Omit 0, 1, 2 because _______
        plot_id,foreign,year = line.split(',')
        if foreign == 'TRUE':
            Foreign[int(year[2:4])-1]=int(Foreign[int(year[2:4])-1])+1
        if foreign == 'FALSE':
            Domestic[int(year[2:4])-1]=int(Domestic[int(year[2:4])-1])+1
    datafile.close()
    filename2 = os.path.join(directory, 'ImmigrationIllegal.csv')
    datafile2 = open(filename2,'r')
    data2 = datafile2.readlines()
    for line in data2:
        year2,IllImm = line.split(',')
        year2= int(year2[2:4])
        NewImm=int(IllImm)/1000000
        IllImmPop[year2-1]=NewImm
    datafile2.close()
    return Foreign,Domestic,IllImmPop
    
def Graph(Stats):
    Foreign,Domestic,IllImmPop=Stats
    ind = np.arange(16)
    width = 0.2
    fig = plt.figure()
    ax = fig.add_subplot(111)
    rects1 = ax.bar(ind, Foreign, width, color='r',)
    rects2 = ax.bar(ind+width, Domestic, width, color='b',)
    rects3 = ax.bar(ind+width*2, IllImmPop, width, color='y',)
    ax.set_ylabel('Terrorist Acts')
    ax.set_title('Terrorist Acts Foreign and Domestic by Year')
    ax.set_xticks(ind+width)
    ax.set_xticklabels( ('2001', '2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013', '2014', '2015','2016') )
    
    ax.legend( (rects1[0], rects2[0], rects3[0]), ('Foreign Attacks', 'Domestic Attacks','Illegal Immigrants Coming In (Millions)') )
    
    plt.show()
       
#Call Main Func 
Graph(Stats())